/* eslint-disable  func-names */
/* eslint-disable max-len */
/* eslint quote-props: ['error', 'consistent']*/
module.exports = {
    'FUNCTIONS_EN': {
        'implode': 'Join array elements with a string',
        'explode': 'Split a string by string'
    },
};
